var _m_d___m_a_x72xx__font_8cpp =
[
    [ "USE_NEW_FONT", "_m_d___m_a_x72xx__font_8cpp.html#a79fc401febb90ff349b60de104786575", null ],
    [ "_sysfont", "_m_d___m_a_x72xx__font_8cpp.html#a257a12eacc1614b3a038b5164fd78e47", null ]
];